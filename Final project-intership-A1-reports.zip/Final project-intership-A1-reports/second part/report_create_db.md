# Отчёт по созданию базы данных в Oracle Database

В этом отчёте я буду показывать, как я создал ещё одну базу данных. Я создал, кроме существующей БД, ещё 2 БД. Мне нужно было создать одну БД кроме существующей, но при установке я забыл убрать галочку для создания контейнера для БД (представил скрин в отчёте). 

В принципе, работать с контейнерами не очень сложно (проходили в вузе), но так как в рамках стажировки этого не было, мне пришлось создать вторую БД без контейнеризации.

Ниже показаны команды для настройки БД перед созданием новой БД:

```bash
[root@amir ~]# su - oracle
Last login: Sat Jan 25 08:16:57 +05 2025 on pts/0
[oracle@amir ~]$ nano  /home/oracle/.bash_profile
```

В файле `/home/oracle/.bash_profile` я изменил только переменную `ORACLE_SID` на новое название БД - `cometanew`:

```bash
[oracle@amir ~]$ cat /home/oracle/.bash_profile 
# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/19.0.0/dbhome_1
export ORACLE_SID=cometanew 
export PATH=$ORACLE_HOME/bin:$PATH
```

Запускаем DBCA (Database Configuration Assistant) для создания БД:

```bash
[oracle@amir ~]$ dbca
```
Появляется такое окно. Сначала я хотел удалить ту БД (которая была с контейнером), но странно что  `delete database` не работал 🤷‍♂️

![](1.png)

Следуем по этим скриншотам которые я сделал и каждый раз нажимаем на `next`

![](2.png)

![](3.png)

![](4.png)

В первой созданной БД я забыл убрать галочку с `Create as Container Database`. Вот скрин:

![](4.old.png)

![](5.png)

![](6.png)

![](7.png)

![](8.png)

![](9.png)

![](10.png)

![](11.png)

![](12.png)

![](13.png)

Теперь нажимаем на `Finish` и ждём создания своей новой БД 😊

![](14.png)

![](15.png)

Всё! У нас БД `cometanew` успешно создана. Однако при запуске БД у нас запускается старая БД. Поэтому сначала в файлах `listener.ora` и `tnsnames.ora` добавим наш новый БД:  
Перешёл в директорию с сетевыми настройками `Oracle Database` и посмотрел содержимое директории:

```bash
[oracle@amir ~]$ cd /u01/app/oracle/product/19.0.0/dbhome_1/network/admin
[oracle@amir admin]$ ls
listener.ora  samples  shrept.lst  tnsnames.ora
```

Отредактировал файл `listener.ora`, чтобы он обрабатывал запросы и для БД - `cometanew`:

```bash
[oracle@amir admin]$ nano listener.ora
```

Содержимое `listener.ora` после редактирования:

```bash
[oracle@amir admin]$ cat listener.ora

LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS_LIST =
        (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.78.236)(PORT = 1521))
      )
    )
  )

SID_LIST_LISTENER =
  (SID_LIST =
    (SID_DESC =
      (SID_NAME = cometa2)  # SID для первой базы данных
      (ORACLE_HOME = /u01/app/oracle/product/19.0.0/dbhome_1)
    )
    (SID_DESC =
      (SID_NAME = cometanew)  # SID для второй базы данных
      (ORACLE_HOME = /u01/app/oracle/product/19.0.0/dbhome_1)
    )
  )
```

Отредактировал файл `tnsnames.ora` для подключения к базе данных `cometanew` (другие БД не добавлял, так как они не содержат важных данных, и особо не нужны):

```bash
[oracle@amir admin]$ nano tnsnames.ora
```

Содержимое `tnsnames.ora` после редактирования

```bash
[oracle@amir admin]$ cat tnsnames.ora
COMETANEW =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.78.236)(PORT = 1521))
    )
    (CONNECT_DATA =
      (SERVICE_NAME = cometanew)
    )
  )
```

Подключился к БД `cometanew` под пользователем `sys` и запустил её `startup`-ом. 

```sql
[oracle@amir dbhome_1]$ sqlplus sys/1234@cometanew as sysdba

SQL*Plus: Release 19.0.0.0.0 - Production on Sat Jan 25 09:36:17 2025
Version 19.3.0.0.0

Copyright (c) 1982, 2019, Oracle.  All rights reserved.

Connected to an idle instance.

SQL> startup
ORACLE instance started.

Total System Global Area 2365586088 bytes
Fixed Size                  8899240 bytes
Variable Size             536870912 bytes
Database Buffers         1811939328 bytes
Redo Buffers                7876608 bytes
Database mounted.
Database opened.
```

Проверил имя базы, экземпляра и статус, чтобы убедиться, что подключился именно к `cometanew`, потому что у меня ещё есть другие базы  


```sql
SQL> select instance_name, status from v$instance;

INSTANCE_NAME    STATUS
---------------- ------------
cometanew        OPEN

SQL> select name from v$database;

NAME
---------
COMETANEW
```