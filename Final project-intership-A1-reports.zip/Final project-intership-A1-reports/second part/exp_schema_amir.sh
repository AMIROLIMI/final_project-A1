#!/bin/bash

expdp amir/1234@cometanew schemas=amir directory=data_pump_dir dumpfile=amir_schema.dmp logfile=amir_schema.log
