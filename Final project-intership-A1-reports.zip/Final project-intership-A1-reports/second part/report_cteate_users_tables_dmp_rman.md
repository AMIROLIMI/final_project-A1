# **Задания 2 и 3** Создал пользователей с различными уровнями привилегий и создал таблицы, заполнил их (Задания 2 и 3 из второй части финального проекта)


## Созданил сначало табличных пространств для пользователей:

```sql
SQL> create tablespace amir_admin datafile 'amir_admin.dbf' size 100M;

Tablespace created.

SQL> create tablespace only_read_user datafile 'only_read_user.dbf' size 100M;

Tablespace created.

SQL> create tablespace regular_user datafile 'regular_user.dbf' size 100M;

Tablespace created.
```

## 1. Пользователь `Amir`

Создаём пользователя `amir` и даём этому пользователю права администратора:

```sql
SQL> create user amir identified by 1234 default tablespace amir_admin;

User created.

SQL> grant dba to amir;

Grant succeeded.
```

Подключился к пользователю `amir` и создал в его схеме таблицу `students` и заполнил её.

```sql
SQL> conn amir/1234@cometanew
Connected.
SQL> create table students (id int, full_name nvarchar2(30), birth_day date);

Table created.

SQL> insert into students values (1, 'Daler', '15-APR-2004');

1 row created.

SQL> insert into students values (2, 'Abdullo', '22-JUN-2004');

1 row created.

SQL> insert into students values (3, 'Munira', '30-SEP-2005');

1 row created.

SQL> insert into students values (4, 'Yusuf', '22-AUG-2004');

1 row created.

SQL> insert into students values (5, 'Umed', '27-SEP-2004');

1 row created.

SQL> insert into students values (6, 'Gulnoza', '25-MAY-2006');

1 row created.

SQL> insert into students values (7, 'Farahnoz', '07-AUG-2004');

1 row created.

SQL> insert into students values (8, 'Khurshed', '14-NOV-2005');

1 row created.

SQL> insert into students values (9, 'Karim', '12-JAN-2005');

1 row created.
```

Посмотрел содержимое таблицы `students`:

```sql
SQL> select * from students;

        ID FULL_NAME                      BIRTH_DAY
---------- ------------------------------ ---------
         1 Daler                          15-APR-04
         2 Abdullo                        22-JUN-04
         3 Munira                         30-SEP-05
         4 Yusuf                          22-AUG-04
         5 Umed                           27-SEP-04
         6 Gulnoza                        25-MAY-06
         7 Farahnoz                       07-AUG-04
         8 Khurshed                       14-NOV-05
         9 Karim                          12-JAN-05

9 rows selected.
```

Создал таблицу `subjects` в схеме `amir` и заполнил её:

```sql
SQL> create table subjects (id int, name nvarchar2(30), semester int);

Table created.

SQL> insert into subjects values (1, 'Mathematical Analysis', 1);

1 row created.

SQL> insert into subjects values (2, 'Linear Algebra', 1);

1 row created.

SQL> insert into subjects values (3, 'Discrete Mathematics', 2);

1 row created.

SQL> insert into subjects values (4, 'Probability Theory', 2);

1 row created.

SQL> insert into subjects values (5, 'Computer Programming', 3);

1 row created.

SQL> insert into subjects values (6, 'Algorithms and Data Structures', 3);

1 row created.

SQL> insert into subjects values (7, 'Numerical Methods', 4);

1 row created.

SQL> insert into subjects values (8, 'Database Systems', 4);

1 row created.

SQL> insert into subjects values (9, 'Operations Research', 5);

1 row created.

SQL> insert into subjects values (10, 'Software Engineering', 6);

1 row created.
```

Посмотрел содержимое таблицы `subjects`:

```sql
SQL> select * from subjects;

        ID NAME                             SEMESTER
---------- ------------------------------ ----------
         1 Mathematical Analysis                   1
         2 Linear Algebra                          1
         3 Discrete Mathematics                    2
         4 Probability Theory                      2
         5 Computer Programming                    3
         6 Algorithms and Data Structures          3
         7 Numerical Methods                       4
         8 Database Systems                        4
         9 Operations Research                     5
        10 Software Engineering                    6

10 rows selected.
```

## 2. Пользователь `only_read`

Создал пользователя only_read, который может только зайти (create session) и просматривать данные любой таблицы (select any table):

```sql
SQL> create user only_read identified by 1234 default tablespace only_read_user;

User created.

SQL> grant create session to only_read;

Grant succeeded.

SQL> grant select any table to only_read;

Grant succeeded.
```

Подключаюсь через пользователя `only_read`, так как у меня есть права на подключение к БД (create session):

```sql
SQL> conn only_read/1234@cometanew;
Connected.
```

Теперь хочу убедиться, что через этого пользователя я могу посмотреть таблицы другого пользователя.

```sql
SQL> select * from amir.students;

        ID FULL_NAME                      BIRTH_DAY
---------- ------------------------------ ---------
         1 Daler                          15-APR-04
         2 Abdullo                        22-JUN-04
         3 Munira                         30-SEP-05
         4 Yusuf                          22-AUG-04
         5 Umed                           27-SEP-04
         6 Gulnoza                        25-MAY-06
         7 Farahnoz                       07-AUG-04
         8 Khurshed                       14-NOV-05
         9 Karim                          12-JAN-05

9 rows selected.

SQL> select * from amir.subjects;

        ID NAME                             SEMESTER
---------- ------------------------------ ----------
         1 Mathematical Analysis                   1
         2 Linear Algebra                          1
         3 Discrete Mathematics                    2
         4 Probability Theory                      2
         5 Computer Programming                    3
         6 Algorithms and Data Structures          3
         7 Numerical Methods                       4
         8 Database Systems                        4
         9 Operations Research                     5
        10 Software Engineering                    6

10 rows selected.
```

Так как у этого пользователя права только на подключение к БД и просмотр любой таблицы, я не могу создавать таблицы. Но хочу убедиться в этом:

```sql
SQL> create table t1 (id int);
create table t1 (id int)
*
ERROR at line 1:
ORA-01031: insufficient privileges
```

## 3. Пользователь `olimov`

Подключился к БД как `sys` и создал нового пользователя `olimov` и дал права на подключение к БД и создание таблиц:

```sql
SQL> conn sys/1234@cometanew as sysdba
Connected.

SQL> create user olimov identified by 1234 default tablespace regular_user;
User created.

SQL> grant create session, create table to olimov;
Grant succeeded.
```

Подключился к БД как пользователь `olimov` и создал таблицу `customers`:

```sql
SQL> conn olimov/1234@cometanew
Connected.

SQL> create table customers (id int, name nvarchar2(20));
Table created.
```

Подключился к БД как пользователь `sys` и дал пользователю `olimov` права на удаление, обновление и вставку данных в таблицу `customers`:

```sql
SQL> conn sys/1234@cometanew as sysdba
Connected.

SQL> grant delete, update, insert on olimov.customers to olimov;
Grant succeeded.
```

Установил квоту в 10 МБ для пользователя `olimov` на табличное пространство `USERS`:

```sql
SQL> ALTER USER olimov QUOTA 10M ON USERS;
User altered.
```

Подключился к БД как `olimov` и вставил данные в таблицу `customers` (так как уже у меня есть права `insert` в таблицу `customers`):

```sql
SQL> conn olimov/1234@cometanew
Connected.

SQL> insert into customers values (1, 'Ali');
1 row created.

SQL> insert into customers values (5, 'Akram');

1 row created.

SQL> insert into customers values (6, 'Zarina');

1 row created.

SQL> insert into customers values (8, 'Shahzad');

1 row created.

SQL> insert into customers values (10, 'Amina');

1 row created.
```

Посмотрел содержимое таблицы `customers`:

```sql
SQL> select * from customers;

        ID NAME
---------- --------------------
         1 Ali
         5 Akram
         6 Zarina
         8 Shahzad
        10 Amina
```

# **Задания 4 и 5**

# DATA PUMP
## 1. expdb

Подключился к базе как `sysdba`, создал каталог `data_pump_dir`, указав путь `/home/oracle/data_pump`, и выдал пользователю `amir` права на чтение и запись в этот каталог.

```sql
[oracle@amir ~]$ sqlplus sys/1234@cometanew as sysdba

SQL*Plus: Release 19.0.0.0.0 - Production on Sat Jan 25 15:07:38 2025
Version 19.3.0.0.0

Copyright (c) 1982, 2019, Oracle.  All rights reserved.


Connected to:
Oracle Database 19c Enterprise Edition Release 19.0.0.0.0 - Production
Version 19.3.0.0.0

SQL> create or replace directory data_pump_dir as '/home/oracle/data_pump';

Directory created.

SQL> grant read, write on directory data_pump_dir to amir;

Grant succeeded.

SQL> exit
Disconnected from Oracle Database 19c Enterprise Edition Release 19.0.0.0.0 - Production
Version 19.3.0.0.0
```

В домашней директории создал папку `data_pump`, перешёл в неё и создал скрипт `exp_schema_amir.sh` для экспорта схемы `amir` с помощью утилиты `expdp`. Указал в скрипте пользователя, схему (schemas=amir), каталог (directory=data_pump_dir), а также имена файлов дампа (dumpfile=amir_schema.dmp) и лога logfile=amir_schema.log. После этого дал скрипту права на выполнение командой `chmod 744` (пользователь `amir` может читать, записать и запустить; 4 - а пользователи группы и другие пользователи только могут читать).

```bash
[oracle@amir ~]$ pwd
/home/oracle
[oracle@amir ~]$ mkdir data_pump
[oracle@amir ~]$ cd data_pump
[oracle@amir data_pump]$ nano exp_schema_amir.sh
[oracle@amir data_pump]$ cat exp_schema_amir.sh
#!/bin/bash

expdp amir/1234@cometanew schemas=amir directory=data_pump_dir dumpfile=amir_schema.dmp logfile=amir_schema.log   
[oracle@amir data_pump]$ chmod 744 exp_schema_amir.sh
[oracle@amir data_pump]$ ls -l
total 4
-rwxr--r--. 1 oracle oinstall 124 Jan 25 15:50 exp_schema_amir.sh
```

Запустил скрипт `exp_schema_amir.sh` для экспорта схемы `amir`. `expdp` успешно завершила процесс, выгрузив данные схемы в файл дампа `amir_schema.dmp` и лог `amir_schema.log`, оба находящиеся в каталоге `/home/oracle/data_pump`. Экспорт прошёл без ошибок.

```bash
[oracle@amir data_pump]$ ./exp_schema_amir.sh

Export: Release 19.0.0.0.0 - Production on Sat Jan 25 16:04:08 2025
Version 19.3.0.0.0

Copyright (c) 1982, 2019, Oracle and/or its affiliates.  All rights reserved.

Connected to: Oracle Database 19c Enterprise Edition Release 19.0.0.0.0 - Production
Starting "AMIR"."SYS_EXPORT_SCHEMA_01":  amir/********@cometanew schemas=amir directory=data_pump_dir dumpfile=amir_schema.dmp logfile=amir_schema.log
Processing object type SCHEMA_EXPORT/TABLE/TABLE_DATA
Processing object type SCHEMA_EXPORT/TABLE/INDEX/STATISTICS/INDEX_STATISTICS
Processing object type SCHEMA_EXPORT/TABLE/STATISTICS/TABLE_STATISTICS
Processing object type SCHEMA_EXPORT/STATISTICS/MARKER
Processing object type SCHEMA_EXPORT/USER
Processing object type SCHEMA_EXPORT/SYSTEM_GRANT
Processing object type SCHEMA_EXPORT/ROLE_GRANT
Processing object type SCHEMA_EXPORT/DEFAULT_ROLE
Processing object type SCHEMA_EXPORT/PRE_SCHEMA/PROCACT_SCHEMA
Processing object type SCHEMA_EXPORT/TABLE/TABLE
Processing object type SCHEMA_EXPORT/TABLE/COMMENT
Processing object type SCHEMA_EXPORT/TABLE/INDEX/INDEX
. . exported "AMIR"."SUBJECTS"                           6.414 KB      10 rows
. . exported "AMIR"."STUDENTS"                           6.164 KB       9 rows
Master table "AMIR"."SYS_EXPORT_SCHEMA_01" successfully loaded/unloaded
******************************************************************************
Dump file set for AMIR.SYS_EXPORT_SCHEMA_01 is:
  /home/oracle/data_pump/amir_schema.dmp
Job "AMIR"."SYS_EXPORT_SCHEMA_01" successfully completed at Sat Jan 25 16:05:03 2025 elapsed 0 00:00:29
```

После выполнения экспорта схемы, для убеждения проверил содержимое каталога `/home/oracle/data_pump`:

```bash
[oracle@amir data_pump]$ ls -l
total 368
-rw-r-----. 1 oracle oinstall 368640 Jan 25 16:05 amir_schema.dmp
-rw-r--r--. 1 oracle oinstall   1580 Jan 25 16:05 amir_schema.log
-rwxr--r--. 1 oracle oinstall    125 Jan 25 16:03 exp_schema_amir.sh
```

## impdb 
Для импорта схемы с помощью DATA PUMP всё почти так же, как и для экспорта, только вместо `expdp` нужно использовать `impdp`, а в `dumpfile` необходимо указать существующий файл, который ранее был **экспортирован** через `expdp`. Итоговый скрипт для экспорта схемы:

```bash
#!/bin/bash

impdp amir/1234@cometanew schemas=amir directory=data_pump_dir dumpfile=amir_schema.dmp logfile=amir_schema_import.log  
```

Кстати можно не только импортировать схему, но и таблицы из экспортированной схемы.

# RMAN

Я создал RMAN-скрипт для резервного копирования базы данных, запустил его вручную, а затем настроил автоматизацию через `cron`. Вот что я сделал:

### Создание RMAN-скрипта

Создал файл в /home/oracle/rman и написал в него команды для резервного копирования БД:

```bash
[oracle@amir rman]$ nano bak_db.rman
[oracle@amir rman]$ cat bak_db.rman
RUN {
  -- Выделяем канал с именем amir_bak
  -- Канал будет использовать формат '/home/oracle/rman/bak_db_%U_%T.bkp'
  ALLOCATE CHANNEL amir_bak DEVICE TYPE DISK FORMAT '/home/oracle/rman/bak_db_%U_%T.bkp';

  -- Выполняем копирование бд
  -- Но если база в режиме NOARCHIVELOG, это вызвает ошибку, и по этому необходимо перейти в режим ARCHIVELOG
  BACKUP DATABASE;

  -- Освобождаем канал после завершения копирования
  RELEASE CHANNEL amir_bak;
}
```

**amir_bak** — это название я просто выбрал, но потом заметил и удивился, что получилось как "Амирбек" 😂😂😂😂😂😂

Я запустил RMAN-скрипт с помощью команды: ```target / @bak_db.rman```

```bash
[oracle@amir rman]$ rman target / @bak_db.rman

Recovery Manager: Release 19.0.0.0.0 - Production on Sat Jan 25 17:19:59 2025
Version 19.3.0.0.0

Copyright (c) 1982, 2019, Oracle and/or its affiliates.  All rights reserved.

connected to target database: COMETANE (DBID=2945847726)

RMAN> RUN {
2>   ALLOCATE CHANNEL amir_bak DEVICE TYPE DISK FORMAT '/home/oracle/rman/bak_db_%U_%T.bkp';
3>   BACKUP DATABASE;
4>   RELEASE CHANNEL amir_bak;
5> }
6>
using target database control file instead of recovery catalog
allocated channel: amir_bak
channel amir_bak: SID=747 device type=DISK

Starting backup at 25-JAN-25
channel amir_bak: starting full datafile backup set
channel amir_bak: specifying datafile(s) in backup set
input datafile file number=00001 name=/u01/app/oracle/oradata/COMETANEW/system01.dbf
input datafile file number=00003 name=/u01/app/oracle/oradata/COMETANEW/sysaux01.dbf
input datafile file number=00004 name=/u01/app/oracle/oradata/COMETANEW/undotbs01.dbf
input datafile file number=00002 name=/u01/app/oracle/product/19.0.0/dbhome_1/dbs/only_read_user.dbf
input datafile file number=00005 name=/u01/app/oracle/product/19.0.0/dbhome_1/dbs/amir_admin.dbf
input datafile file number=00008 name=/u01/app/oracle/product/19.0.0/dbhome_1/dbs/regular_user.dbf
input datafile file number=00007 name=/u01/app/oracle/oradata/COMETANEW/users01.dbf
channel amir_bak: starting piece 1 at 25-JAN-25
channel amir_bak: finished piece 1 at 25-JAN-25
piece handle=/home/oracle/rman/bak_db_013g4vec_1_1_20250125.bkp tag=TAG20250125T172012 comment=NONE
channel amir_bak: backup set complete, elapsed time: 00:00:07
Finished backup at 25-JAN-25

Starting Control File and SPFILE Autobackup at 25-JAN-25
piece handle=/u01/app/oracle/product/19.0.0/dbhome_1/dbs/c-2945847726-20250125-00 comment=NONE
Finished Control File and SPFILE Autobackup at 25-JAN-25

released channel: amir_bak

Recovery Manager complete.
```

Эта команда выполняет следующее:
- `rman target /` — подключение к бд 
- `@bak_db.rman` — указывает на файл RMAN-скрипта, который должен быть выполнен. В данном случае это файл `bak_db.rman`, в котором прописаны команды для резервного копирования бд.

Я проверил содержимое директории `/home/oracle/rman`, чтобы убедиться, что резервное копирование бд завершилось успешно:

```bash
[oracle@amir rman]$ ls -l
total 1259736
-rw-r-----. 1 oracle oinstall 1289961472 Jan 25 17:20 bak_db_013g4vec_1_1_20250125.bkp
-rw-r--r--. 1 oracle oinstall        145 Jan 25 17:14 bak_db.rman
```
## Автоматизация рес помощью Cron

Открыл crontab:
```
[oracle@amir rman]$ crontab -e
```

и добавил в нём:

```
0 0 * * * /usr/bin/rman target / @/home/oracle/rman/bac_db.rman > /home/oracle/rman/bac_db.log 2>&1
```

Этот скрипт указывает на выполнение RMAN-скрипта (`/usr/bin/rman target / @/home/oracle/rman/bac_db.rman`), ежедневно в 00:00 (`0 0 * * *`),  перенаправляя вывод в лог-файл (`> /home/oracle/rman/bac_db.log 2>&1`).
