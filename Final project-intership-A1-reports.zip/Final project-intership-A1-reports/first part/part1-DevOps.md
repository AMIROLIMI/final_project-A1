# Отчёт по проекту DevOps

Этот проект был направлен на разработку веб-приложения и настройку автоматизированного конвейера для его развертывания. Приложение развёрнуто на виртуальной машине с использованием Docker, Ansible и GitHub Actions. В рамках проекта реализованы следующие этапы:

1. Разработка веб-приложения.
2. Создание Docker-контейнера для приложения.
3. Настройка Ansible playbook для автоматизации развертывания.
4. Настройка конвейера CI/CD с использованием GitHub Actions.

Результатами проекта являются успешно созданное веб-приложение, его деплой в контейнере и автоматизированный процесс развёртывания.

---

## Этапы выполнения проекта

## **Примечание: Содержимое всех файлов можно посмотреть на моём гитхабе по ссылке** [https://github.com/AMIROLIMI/final_project-A1](https://github.com/AMIROLIMI/final_project-A1)

### 1. Создание веб-приложения
Для веб-приложения я выбрал Python с использованием фреймворка Flask. Приложение представляет собой простую веб-страницу, где пользователь должен угадать страну, из которой я родом. Функциональность включает:

- Отображение приветственного экрана с формой для ввода страны.
- Проверку правильности ввода (например, "Таджикистан").
- Вывод результата (успех или неудача).

**Основные файлы:**
- `web_page.py`: Python-код приложения.
- Шаблоны HTML для страниц (`index.html`, `rezult.html`).
- Статические ресурсы: CSS-файл для стилизации.

Приложение было протестировано локально и успешно работало на порту 8000.

### 2. Создание Docker-контейнера

Для контейнеризации приложения был создан `Dockerfile`, включающий следующие этапы:

- Использование базового образа `python:3.9-slim` для минимального размера.
- Копирование исходного кода приложения в контейнер.
- Установка всех зависимостей из `dependencies.txt`.
- Запуск приложения на стандартном порту 8000.

**Dockerfile:**
```dockerfile
# Используем официальный образ Python 3.12 slim (облегченный)
FROM python:3.12.3-slim

# Устанавливаем рабочую директорию контейнера
WORKDIR /app

# Копируем файл зависимостей
COPY dependencies.txt .

# Устанавливаем зависимости из файла requirements.txt
RUN pip install --no-cache-dir -r dependencies.txt

# Копируем весь проект в рабочую директорию
COPY . .

# Открываем порт 8000 для доступа к Flask-приложению
EXPOSE 8000

# Указываем команду для запуска приложения
CMD ["python", "web_page.py"]
```

**Оптимизация:**
- Использован минималистичный образ Python (`slim`).
- Установка зависимостей выполняется с использованием `--no-cache-dir`, чтобы минимизировать размер слоя.

### 3. Настройка Ansible

Для автоматизации развертывания приложения на виртуальной машине был создан Ansible playbook. Этот playbook:

1. Устанавливает Docker на удалённый сервер (если он ещё не установлен).  
2. Копирует исходные файлы приложения на сервер.  
3. Собирает Docker-образ приложения из локальных файлов.  
4. Запускает контейнер с приложением на указанном порту.  

**Ansible playbook:**
```yaml
- name: Deploy and Configure a Flask Web Application with Docker
  hosts: ec2_servers
  become: yes

  tasks:
    - name: Update apt package cache to ensure latest package info
      ansible.builtin.apt:
        update_cache: yes

    - name: Install essential system dependencies for Docker setup
      ansible.builtin.apt:
        name:
          - apt-transport-https
          - ca-certificates
          - curl
          - software-properties-common
        state: present

    - name: Add the official Docker GPG key to verify downloads
      ansible.builtin.apt_key:
        url: https://download.docker.com/linux/ubuntu/gpg
        state: present

    - name: Add Docker's official repository for package installation
      ansible.builtin.apt_repository:
        repo: "deb [arch=amd64] https://download.docker.com/linux/ubuntu {{ ansible_lsb.codename }} stable"
        state: present

    - name: Update apt cache after adding Docker's repository
      ansible.builtin.apt:
        update_cache: yes

    - name: Install Docker
      ansible.builtin.apt:
        name: docker-ce
        state: present

    - name: Ensure Docker is started and enabled
      ansible.builtin.service:
        name: docker
        state: started
        enabled: yes

    - name: Copy application files to server
      ansible.builtin.copy:
        src: /home/ubuntu/final_project-A1/web_page
        dest: /home/ubuntu/final_project-A1/web_page
        owner: "ubuntu"
        group: "ubuntu"
        mode: 0755

    - name: Build Docker image
      ansible.builtin.command:
        cmd: docker build -t simple-flask-app /home/ubuntu/final_project-A1/web_page
      args:
        chdir: /home/ubuntu/final_project-A1/web_page

    - name: Ensure the Flask Docker container is running and accessible
      ansible.builtin.docker_container:
        name: simple-flask-app
        image: simple-flask-app
        state: started
        restart_policy: always
        published_ports:
          - 8000:8000
```

Playbook был протестирован и успешно развёртывал приложение на сервере.

---

### 4. Настройка GitHub Actions  

Workflow автоматизирует CI/CD процесс и выполняет:  

1. **Сборку Docker-образа** при каждом пуше в ветку `master`.  
2. **Публикацию образа в Docker Hub** с тегом `latest`.  
3. **Развертывание на сервере**:  
   - Удаление старого контейнера.  
   - Загрузка нового образа из Docker Hub.  
   - Запуск контейнера на порту 8000.  
4. **Проверку работы контейнера** через вывод списка активных контейнеров.  

Используются GitHub Secrets для безопасного хранения учетных данных (Docker Hub, SSH-ключ, IP сервера). Workflow запускается автоматически и исключает ручное развертывание.  

**Файл workflow:**
```yaml
name: Deploy and Run Flask Web Application on EC2

on:
  push:
    branches:
      - master  

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest 

    steps:
      - name: Checkout the repository
        uses: actions/checkout@v3

      - name: List directory contents
        run: |
          ls -R  # Рекурсивный вывод всех файлов

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v2

      - name: Log in to Docker Hub
        uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKER_USERNAME }}
          password: ${{ secrets.DOCKER_PASSWORD }}


      - name: Build Docker image
        run: |
          cd web_page  # Переход в директорию с Dockerfile и кодом приложения
          docker build -t ${{ secrets.DOCKER_USERNAME }}/guessing-game-flask-app:latest -f Dockerfile .

      - name: Push Docker image to Docker Hub
        run: |
          docker push ${{ secrets.DOCKER_USERNAME }}/guessing-game-flask-app:latest


      - name: Deploy to EC2 with SSH
        uses: appleboy/ssh-action@v1.0.3
        with:
          host: ${{ secrets.REMOTE_HOST }}  
          username: ${{ secrets.REMOTE_USER }}  
          key: ${{ secrets.SSH_PRIVATE_KEY }}  
          script: |
            # Удаление существующего контейнера, если он есть
            sudo docker container rm -f guessing-game-flask-app || true
            # Загрузка последней версии Docker-образа
            sudo docker pull ${{ secrets.DOCKER_USERNAME }}/guessing-game-flask-app:latest
            # Запуск нового контейнера с приложением
            sudo docker run -d --name guessing-game-flask-app -p 8000:8000 ${{ secrets.DOCKER_USERNAME }}/guessing-game-flask-app:latest
            # Проверка состояния запущенных контейнеров
            sudo docker ps
```


## Результаты

- **Веб-приложение:** Доступно по HTTP на порту 8000.
- **Docker-контейнер:** Создан оптимизированный образ с приложением, опубликован в Docker Hub.
- **Ansible:** Автоматизировано развертывание приложения на удалённом сервере.
- **GitHub Actions:** Полностью настроен CI/CD конвейер, обеспечивающий сборку, публикацию и деплой приложения при каждом изменении в репозитории.

Ввёл в браузере [http://3.70.250.187:8000/](http://3.70.250.187:8000/) (вы тоже можете перейти по этой ссылке и посмотреть веб-приложение, если я ещё не выключил инстанс AWS) и вот результат:

![](1.png)

![](2.png)

![](3.png)

![](4.png)

---

## Инструкции для развертывания

1. **Клонировать репозиторий:**
   ```bash
   git clone https://github.com/AMIROLIMI/final_project-A1.git
   cd final_project-A1
   ```

2. **Запустить локально:**
   ```bash
   docker build -t simple-flask-app .
   docker run -p 8000:8000 simple-flask-app
   ```
   Приложение будет доступно по [http://localhost:8000](http://localhost:8000).

3. **Автоматическое развертывание:**
   - Настройте секреты в GitHub (Docker Hub, SSH).
   - Сделайте коммит в ветку `master` для автоматического запуска CI/CD через GitHub Actions, который выполнит сборку, публикацию и развертывание приложения.
   Приложение будет доступно по [http://<тут добавьте ваш ID>:8000](http://localhost:8000).


## Итоги выполнения проекта

- **Веб-приложение:** Приложение успешно развернуто и доступно по HTTP на порту 8000. Оно проверяет ввод пользователя и предоставляет обратную связь.
  
- **Docker-контейнер:** Контейнер с приложением создан с оптимизированным `Dockerfile`, протестирован локально и на сервере.

- **CI/CD:** Настроен конвейер с GitHub Actions, который автоматически собирает Docker-образ, публикует его в Docker Hub и деплоит приложение на сервер с помощью Ansible.

- **Документация:** Все этапы проекта, включая инструкции для локального запуска и развертывания, описаны в отчёте и доступны в GitHub-репозитории.

